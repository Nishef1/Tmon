import Link from "next/link";
import { apiGet, type Calibration, type CalibrationBlock } from "@/lib/api";
import { faDigits, friendlyWarning, jalali } from "@/lib/format";
import { ErrorState } from "@/components/ErrorState";
import { Num } from "@/components/Num";

function Reliability({ block }: { block: CalibrationBlock }) {
  const rows = block.buckets.filter((b) => b.n > 0);
  if (rows.length === 0) return <p className="text-sm text-muted">دادهٔ کافی وجود ندارد.</p>;
  return (
    <div className="overflow-x-auto">
      <table className="tbl min-w-[32rem]">
        <caption className="sr-only">احتمال پیش‌بینی‌شده در برابر نرخ موفقیت واقعی</caption>
        <thead>
          <tr className="border-b border-line">
            <th scope="col">بازهٔ احتمال</th>
            <th scope="col">نمونه</th>
            <th scope="col">پیش‌بینی</th>
            <th scope="col">واقعی</th>
            <th scope="col" className="w-1/3">
              مقایسه
            </th>
          </tr>
        </thead>
        <tbody>
          {rows.map((b) => (
            <tr key={b.bucket} className="border-b border-line last:border-0">
              <td className="px-2 py-1.5">
                <bdi dir="ltr">{faDigits(b.bucket)}</bdi>
              </td>
              <td className="px-2 py-1.5">
                <Num term="sample_size" value={b.n} kind="count" />
              </td>
              <td className="px-2 py-1.5">
                <Num term="p_win" value={b.mean_p} kind="percent" digits={0} />
              </td>
              <td className="px-2 py-1.5">
                <Num term="hit_rate" value={b.hit_rate} kind="percent" digits={0} />
              </td>
              <td className="px-2 py-1.5" aria-hidden="true">
                <div className="h-2 rounded bg-accent-soft">
                  <div
                    className="h-2 rounded bg-muted/60"
                    style={{ width: `${Math.round((b.mean_p ?? 0) * 100)}%` }}
                  />
                </div>
                <div className="mt-1 h-2 rounded bg-accent-soft">
                  <div
                    className="h-2 rounded bg-accent"
                    style={{ width: `${Math.round((b.hit_rate ?? 0) * 100)}%` }}
                  />
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      <p className="mt-2 text-xs text-muted">
        نوار بالا احتمالی است که مدل پیش‌بینی کرده و نوار پایین درصد موفقیت واقعی. اگر احتمال‌های
        مدل با واقعیت هم‌خوان (کالیبره) باشند، دو نوار تقریباً هم‌اندازه‌اند.
      </p>
    </div>
  );
}

function Stats({ block }: { block: CalibrationBlock }) {
  return (
    <dl className="grid grid-cols-2 gap-3 text-sm sm:grid-cols-5">
      {[
        ["نمونه", <Num key="n" term="sample_size" value={block.n} kind="count" />],
        [
          "درصد موفقیت کل",
          <Num key="b" term="base_rate" value={block.base_rate} kind="percent" digits={1} />,
        ],
        ["AUC", <Num key="a" term="auc" value={block.auc} digits={3} />],
        ["خطای احتمال (Brier)", <Num key="br" term="brier" value={block.brier} digits={3} />],
        [
          "مهارت نسبت به حدس ثابت",
          <Num key="s" term="brier_skill" value={block.brier_skill} digits={3} signed />,
        ],
      ].map(([label, node]) => (
        <div key={String(label)} className="well">
          <dt className="text-xs text-muted">{label}</dt>
          <dd className="text-lg font-bold">{node}</dd>
        </div>
      ))}
    </dl>
  );
}

export async function CalibrationSection() {
  const res = await apiGet<Calibration>("/metrics/calibration", { timeframe: "D1" });
  return (
    <section id="calibration" className="scroll-mt-20 space-y-5">
      <div>
        <h2 className="text-xl font-extrabold">هم‌خوانی احتمال‌ها با واقعیت (کالیبراسیون)</h2>
        <p className="mt-1 text-sm text-muted">
          وقتی مدل احتمال ۶۰٪ می‌دهد، آیا حدود ۶۰٪ آن موارد واقعاً موفق می‌شوند؟ این بخش هم نتیجهٔ
          آزمون روی گذشته (خارج از نمونهٔ آموزش) و هم نتیجهٔ سیگنال‌های واقعاً منتشرشده را نشان
          می‌دهد.
        </p>
      </div>
      {!res.ok ? (
        <ErrorState message={res.error} />
      ) : (
        <>
          <section className="card text-sm">
            {res.data.model_version ? (
              <p>
                نسخهٔ مدل: <bdi dir="ltr">{res.data.model_version}</bdi>
                {res.data.trained_through && (
                  <> · آموزش تا {jalali(res.data.trained_through, "long")}</>
                )}
              </p>
            ) : (
              <p data-testid="no-model">هنوز مدلی آموزش داده نشده است.</p>
            )}
            {res.data.gate && (
              <div className="mt-3" data-testid="gate">
                <p className="font-semibold">
                  {res.data.gate.tier_a_allowed
                    ? "شرط‌های انتشار سیگنال رده A برقرار است."
                    : "سیگنال رده A منتشر نمی‌شود، چون شرط‌های زیر برقرار نیست:"}
                </p>
                {res.data.gate.reasons.length > 0 && (
                  <ul className="mt-1 list-inside list-disc text-muted">
                    {res.data.gate.reasons.map((r) => (
                      <li key={r}>{faDigits(r)}</li>
                    ))}
                  </ul>
                )}
              </div>
            )}
          </section>

          {res.data.warnings.length > 0 && (
            <aside className="alert-warn alert-lg">
              <p className="font-semibold">هشدارها</p>
              <ul className="mt-1 list-inside list-disc">
                {res.data.warnings.map((w) => (
                  <li key={w}>{friendlyWarning(w)}</li>
                ))}
              </ul>
            </aside>
          )}

          <section className="card space-y-3">
            <h2 className="font-bold">آزمون گذشته‌نگر (خارج از نمونه)</h2>
            {res.data.backtest ? (
              <>
                <Stats block={res.data.backtest} />
                <Reliability block={res.data.backtest} />
              </>
            ) : (
              <p className="text-sm text-muted">نتیجهٔ آزمونی ثبت نشده است.</p>
            )}
          </section>

          <section className="card space-y-3">
            <h2 className="font-bold">سیگنال‌های منتشرشده (نتیجهٔ واقعی)</h2>
            {res.data.live.n === 0 ? (
              <p className="text-sm text-muted" data-testid="no-live">
                هنوز سیگنالی منتشر و بسته نشده است؛ پس از بسته شدن اولین سیگنال‌ها این بخش پر
                می‌شود.
              </p>
            ) : (
              <>
                <Stats block={res.data.live} />
                <Reliability block={res.data.live} />
              </>
            )}
          </section>

          <p className="text-sm">
            معنی هر عدد در{" "}
            <Link href="/glossary" className="text-accent underline">
              واژه‌نامه
            </Link>{" "}
            آمده است.
          </p>
        </>
      )}
    </section>
  );
}
