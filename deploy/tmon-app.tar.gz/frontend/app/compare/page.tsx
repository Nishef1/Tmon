import Link from "next/link";
import type { Metadata } from "next";
import {
  apiGet,
  type Compare,
  type Funds,
  type InstrumentDashboard,
  type InstrumentDetail,
} from "@/lib/api";
import { faNumber, jalali } from "@/lib/format";
import { CompareChart } from "@/components/compare/CompareChart";
import { SymbolPicker } from "@/components/compare/SymbolPicker";
import { SymbolsTable, type Picked } from "@/components/compare/SymbolsTable";
import { MAX_SYMBOLS } from "@/components/compare/colors";
import { ErrorState } from "@/components/ErrorState";
import { Num } from "@/components/Num";

export const metadata: Metadata = { title: "مقایسه" };
export const dynamic = "force-dynamic";

type Search = { months?: string; source?: string; s?: string };
const MONTHS = [1, 3, 12] as const;

export default async function ComparePage({ searchParams }: { searchParams: Promise<Search> }) {
  const sp = await searchParams;
  const months = MONTHS.find((m) => String(m) === sp.months) ?? 12;
  const source = sp.source === "cbi" ? "cbi" : "sci";
  const ids = [...new Set((sp.s ?? "").split(",").filter((x) => /^\d+$/.test(x)))].slice(
    0,
    MAX_SYMBOLS,
  );
  const [cmp, funds, picked] = await Promise.all([
    apiGet<Compare>("/compare", { months, inflation_source: source }),
    apiGet<Funds>("/funds"),
    Promise.all(
      ids.map(async (id): Promise<Picked | null> => {
        const [d, dash] = await Promise.all([
          apiGet<InstrumentDetail>(`/instruments/${id}`),
          apiGet<InstrumentDashboard>(`/instruments/${id}/dashboard`),
        ]);
        return d.ok ? { detail: d.data, dash: dash.ok ? dash.data : null } : null;
      }),
    ),
  ]);
  const chosen = picked.filter((p): p is Picked => p != null);
  const sq = chosen.length ? `&s=${chosen.map((p) => p.detail.instrument.id).join(",")}` : "";
  const lines = chosen.map((p) => ({
    id: p.detail.instrument.id,
    symbol: p.detail.instrument.symbol,
    closes: p.detail.candles.flatMap((c) =>
      c.close == null ? [] : [{ date: c.date, close: c.close }],
    ),
  }));

  return (
    <div className="space-y-6">
      <div>
        <h1 className="page-title">مقایسه</h1>
        <p className="lead">
          چند نماد را کنار هم بگذارید: بازده از یک روز مشترک، ریسک، این‌که الان چند کندل سبز یا قرمز
          پشت سر هم دارند و بعد از چنین وضعی در گذشته کندل‌های بعدی چند بار بالاتر رفته‌اند.
          پایین‌تر، دارایی‌های ساده و صندوق‌ها در برابر تورم آمده‌اند.
        </p>
        <nav aria-label="بخش‌های صفحه" className="mt-3 flex flex-wrap gap-2">
          <a href="#symbols" className="tab tab-pill">
            مقایسهٔ نمادها
          </a>
          <a href="#inflation" className="tab tab-pill">
            دارایی‌ها و تورم
          </a>
          <a href="#funds" className="tab tab-pill">
            صندوق‌ها
          </a>
        </nav>
      </div>

      <section id="symbols" className="card space-y-4" data-testid="compare-symbols">
        <h2 className="font-bold">مقایسهٔ نمادها</h2>
        <SymbolPicker
          chosen={chosen.map((p) => ({
            id: p.detail.instrument.id,
            symbol: p.detail.instrument.symbol,
          }))}
          keep={`months=${months}&source=${source}`}
        />
        {chosen.length === 0 ? (
          <p className="text-sm text-muted">
            یک تا {faNumber(MAX_SYMBOLS)} نماد اضافه کنید تا بازده، ریسک و شانس کندل‌های بعدی‌شان
            کنار هم دیده شود.
          </p>
        ) : (
          <>
            <CompareChart lines={lines} />
            <SymbolsTable picked={chosen} />
          </>
        )}
      </section>

      <h2 id="inflation" className="text-xl font-extrabold">
        دارایی‌ها در برابر تورم
      </h2>
      <nav className="flex flex-wrap gap-2 text-sm" aria-label="بازهٔ زمانی و منبع تورم">
        {MONTHS.map((m) => (
          <Link
            key={m}
            href={`/compare?months=${m}&source=${source}${sq}#inflation`}
            aria-current={m === months ? "page" : undefined}
            className="tab"
          >
            {faNumber(m)} ماه
          </Link>
        ))}
        {(["sci", "cbi"] as const).map((s) => (
          <Link
            key={s}
            href={`/compare?months=${months}&source=${s}${sq}#inflation`}
            aria-current={s === source ? "page" : undefined}
            className="tab"
          >
            {s === "sci" ? "مرکز آمار" : "بانک مرکزی"}
          </Link>
        ))}
      </nav>

      {!cmp.ok ? (
        <ErrorState message={cmp.error} />
      ) : cmp.data.as_of == null ? (
        <p className="text-sm text-muted">هنوز دادهٔ بازار آزاد ثبت نشده است.</p>
      ) : (
        <section className="card space-y-3">
          <p className="text-sm">
            تا {jalali(cmp.data.as_of)} — تورم دوره:{" "}
            {cmp.data.inflation ? (
              <Num value={cmp.data.inflation.value} kind="percent" term="inflation" digits={1} />
            ) : (
              <span className="text-muted">برای این منبع و بازه منتشر یا وارد نشده است</span>
            )}
            {cmp.data.annualised_monthly != null && (
              <>
                {" "}
                · تورم ماه آخر سالانه‌شده:{" "}
                <Num
                  value={cmp.data.annualised_monthly}
                  kind="percent"
                  term="inflation_threshold"
                  digits={1}
                />
              </>
            )}
          </p>
          <div className="overflow-x-auto">
            <table className="tbl min-w-[32rem]">
              <caption className="sr-only">بازده اسمی و واقعی دارایی‌ها</caption>
              <thead>
                <tr className="border-b border-line">
                  <th scope="col">دارایی</th>
                  <th scope="col">از</th>
                  <th scope="col">بازده اسمی</th>
                  <th scope="col">بازده واقعی</th>
                  <th scope="col">از تورم جلو؟</th>
                </tr>
              </thead>
              <tbody>
                {cmp.data.rows.map((r) => (
                  <tr key={r.series} className="border-b border-line last:border-0">
                    <td className="px-2 py-1.5">{r.label}</td>
                    <td className="px-2 py-1.5">{r.start_date ? jalali(r.start_date) : "—"}</td>
                    <td className="px-2 py-1.5">
                      {r.nominal_return != null ? (
                        <Num
                          value={r.nominal_return}
                          kind="percent"
                          term="nominal_return"
                          digits={1}
                          signed
                        />
                      ) : (
                        <span className="text-muted">{r.note ?? "—"}</span>
                      )}
                    </td>
                    <td className="px-2 py-1.5">
                      {r.real_return != null ? (
                        <Num
                          value={r.real_return}
                          kind="percent"
                          term="real_return"
                          digits={1}
                          signed
                        />
                      ) : (
                        "—"
                      )}
                    </td>
                    <td className="px-2 py-1.5">
                      {r.beats_inflation == null ? "—" : r.beats_inflation ? "بله" : "خیر"}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {cmp.data.inflation && (
            <ul className="text-xs text-muted">
              {cmp.data.inflation.releases.map((x) => (
                <li key={`${x.ref_period}`}>
                  ماه {jalali(x.ref_period)}، منتشرشده {jalali(x.release_date)}
                  {x.source_url && (
                    <>
                      {" — "}
                      <a href={x.source_url} className="underline" rel="noreferrer" target="_blank">
                        منبع
                      </a>
                    </>
                  )}
                </li>
              ))}
            </ul>
          )}
        </section>
      )}

      <section id="funds" className="card space-y-3">
        <h2 className="font-bold">صندوق‌های بورسی: NAV و حباب</h2>
        {!funds.ok ? (
          <ErrorState message={funds.error} />
        ) : funds.data.funds.length === 0 ? (
          <p className="text-sm text-muted">هنوز NAV صندوقی ثبت نشده است.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="tbl min-w-[32rem]">
              <caption className="sr-only">ارزش ابطال و حباب صندوق‌ها</caption>
              <thead>
                <tr className="border-b border-line">
                  <th scope="col">نماد</th>
                  <th scope="col">NAV ابطال</th>
                  <th scope="col">قیمت پایانی</th>
                  <th scope="col">حباب</th>
                </tr>
              </thead>
              <tbody>
                {funds.data.funds.map((f) => (
                  <tr key={f.reg_no} className="border-b border-line last:border-0">
                    <td className="px-2 py-1.5">
                      {f.instrument_id ? (
                        <Link href={`/instruments/${f.instrument_id}`} className="underline">
                          {f.symbol ?? f.name}
                        </Link>
                      ) : (
                        f.name
                      )}
                    </td>
                    <td className="px-2 py-1.5">
                      {f.cancel_nav != null ? (
                        <Num value={f.cancel_nav} kind="price" term="fund_nav" />
                      ) : (
                        "—"
                      )}
                    </td>
                    <td className="px-2 py-1.5">
                      {f.price != null ? (
                        <Num value={f.price} kind="price" term="last_price" />
                      ) : (
                        "—"
                      )}
                    </td>
                    <td className="px-2 py-1.5">
                      {f.bubble != null && (
                        <Num value={f.bubble} kind="percent" term="etf_bubble" digits={1} signed />
                      )}
                      {f.bubble_note && (
                        <span className="block text-xs text-muted">{f.bubble_note}</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
}
